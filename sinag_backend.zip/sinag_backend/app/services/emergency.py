from app.firebase_config import set_data, get_data


def trigger_emergency(emergency_type):
    state = {
        "type": emergency_type,
        "active": True
    }
    set_data("emergency", state)
    return state


def get_emergency():
    data = get_data("emergency")
    if not data:
        return {"type": None, "active": False}
    return data