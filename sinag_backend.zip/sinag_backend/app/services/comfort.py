def compute_comfort_score(
    temperature,
    humidity,
    airflow,
    occupancy,
    smoke_level,
    weather
):
    score = 100

    ideal_temp = 26
    temp_penalty = abs(temperature - ideal_temp) * 2
    score -= temp_penalty

    humidity_penalty = max(0, humidity - 60) * 0.5
    score -= humidity_penalty

    airflow_bonus = airflow * 4
    score += airflow_bonus

    occupancy_penalty = occupancy * 0.4
    score -= occupancy_penalty

    smoke_penalty = smoke_level * 0.1
    score -= smoke_penalty

    outdoor_temp = weather["outdoor_temperature"]
    if outdoor_temp > 34:
        score -= (outdoor_temp - 34) * 3

    if weather["rain_forecast"]:
        score -= 6

    score = max(0, min(100, round(score, 2)))

    if score >= 85:
        label = "Excellent"
    elif score >= 70:
        label = "Comfortable"
    elif score >= 50:
        label = "Moderate"
    elif score >= 30:
        label = "Poor"
    else:
        label = "Dangerous"

    return score, label