import networkx as nx
from app.services.emergency import get_emergency

graph = nx.Graph()

graph.add_edge("Library", "Hallway", weight=5)
graph.add_edge("Classroom A", "Hallway", weight=4)
graph.add_edge("Waiting Area", "Hallway", weight=3)
graph.add_edge("Cafeteria", "Hallway", weight=6)
graph.add_edge("Library", "Waiting Area", weight=6)
graph.add_edge("Waiting Area", "Cafeteria", weight=5)


def get_route(start, destination):
    emergency = get_emergency()
    temp_graph = graph.copy()

    if emergency["active"]:
        if emergency["type"] == "fire":
            if temp_graph.has_node("Hallway"):
                temp_graph.remove_node("Hallway")

        elif emergency["type"] == "flood":
            if temp_graph.has_node("Waiting Area"):
                temp_graph.remove_node("Waiting Area")

        elif emergency["type"] == "earthquake":
            if temp_graph.has_node("Classroom A"):
                temp_graph.remove_node("Classroom A")

    try:
        route = nx.shortest_path(temp_graph, start, destination, weight="weight")
        distance = nx.shortest_path_length(temp_graph, start, destination, weight="weight")
        eta = round(distance * 0.8, 2)

        return {
            "route": route,
            "distance": distance,
            "eta_minutes": eta
        }

    except Exception:
        return {"error": "No safe route available"}