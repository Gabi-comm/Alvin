from app.firebase_config import get_data


def get_recommendations():
    sensors = get_data("sensors")

    if not sensors:
        return []

    ranked = sorted(
        sensors.values(),
        key=lambda x: x["comfort_score"],
        reverse=True
    )

    recommendations = []

    for sensor in ranked[:3]:
        recommendations.append({
            "location": sensor["location_name"],
            "comfort_score": sensor["comfort_score"],
            "explanation": (
                f'{sensor["location_name"]} recommended because '
                f'low smoke, better airflow, and higher comfort score.'
            )
        })

    return recommendations