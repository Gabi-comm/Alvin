import random
import time
import threading
from datetime import datetime
from app.firebase_config import set_data
from app.services.comfort import compute_comfort_score
from app.weather import fetch_weather

LOCATIONS = [
    ("Library", 14.5995, 120.9842),
    ("Classroom A", 14.5996, 120.9844),
    ("Hallway", 14.5997, 120.9846),
    ("Waiting Area", 14.5998, 120.9848),
    ("Cafeteria", 14.6000, 120.9850)
]

fire_mode = False
heat_mode = False


def set_fire_mode(state: bool):
    global fire_mode
    fire_mode = state


def set_heat_mode(state: bool):
    global heat_mode
    heat_mode = state


def generate():
    weather = fetch_weather()
    all_data = {}

    for name, lat, lng in LOCATIONS:
        temp = random.uniform(24, 42)
        humidity = random.uniform(40, 90)
        airflow = random.uniform(0, 5)
        occupancy = random.randint(0, 50)
        smoke = random.uniform(0, 100)

        if fire_mode:
            smoke += random.uniform(500, 900)

        if heat_mode:
            temp += random.uniform(3, 8)

        score, _ = compute_comfort_score(
            temp,
            humidity,
            airflow,
            occupancy,
            smoke,
            weather
        )

        sensor = {
            "location_name": name,
            "temperature": round(temp, 2),
            "humidity": round(humidity, 2),
            "airflow": round(airflow, 2),
            "occupancy": occupancy,
            "smoke_level": round(smoke, 2),
            "latitude": lat,
            "longitude": lng,
            "comfort_score": score,
            "timestamp": datetime.utcnow().isoformat()
        }

        all_data[name] = sensor

    set_data("sensors", all_data)


def sensor_loop():
    while True:
        generate()
        time.sleep(5)


def start_sensor_thread():
    thread = threading.Thread(target=sensor_loop, daemon=True)
    thread.start()