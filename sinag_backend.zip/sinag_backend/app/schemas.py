from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class SensorData(BaseModel):
    location_name: str
    temperature: float
    humidity: float
    airflow: float
    occupancy: int
    smoke_level: float
    latitude: float
    longitude: float
    comfort_score: Optional[float] = None
    timestamp: datetime