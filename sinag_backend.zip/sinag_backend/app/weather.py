import os
import time
import requests
from dotenv import load_dotenv
from app.firebase_config import set_data

load_dotenv()

API_KEY = os.getenv("OPENWEATHER_API_KEY")
CITY = os.getenv("CITY")

weather_cache = None
last_fetch = 0
CACHE_SECONDS = 600


def fetch_weather():
    global weather_cache, last_fetch

    current_time = time.time()

    if weather_cache and current_time - last_fetch < CACHE_SECONDS:
        return weather_cache

    try:
        url = (
            "https://api.openweathermap.org/data/2.5/weather"
            f"?q={CITY}&appid={API_KEY}&units=metric"
        )

        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()

        weather = {
            "outdoor_temperature": data["main"]["temp"],
            "humidity": data["main"]["humidity"],
            "rain_forecast": "rain" in data["weather"][0]["main"].lower(),
            "wind_speed": data["wind"]["speed"],
            "weather_condition": data["weather"][0]["main"],
            "alerts": "None"
        }

        weather_cache = weather
        last_fetch = current_time
        set_data("weather", weather)

        return weather

    except Exception:
        fallback = {
            "outdoor_temperature": 32,
            "humidity": 70,
            "rain_forecast": False,
            "wind_speed": 2,
            "weather_condition": "Unknown",
            "alerts": "API Failure"
        }

        weather_cache = fallback
        return fallback