from fastapi import APIRouter
from app.services.emergency import trigger_emergency, clear_emergency
from app.mock_data import set_fire_mode, set_heat_mode

router = APIRouter()


@router.post("/api/emergency/fire")
def fire():
    set_fire_mode(True)
    return trigger_emergency("fire")


@router.post("/api/emergency/flood")
def flood():
    return trigger_emergency("flood")


@router.post("/api/emergency/earthquake")
def earthquake():
    return trigger_emgency("earthquake")


@router.post("/api/emergency/extreme-heat")
def extreme_heat():
    set_heat_mode(True)
    return trigger_emergency("extreme-heat")


@router.post("/api/emergency/reset")
def reset():
    set_fire_mode(False)
    set_heat_mode(False)
    return clear_emergency()