from fastapi import APIRouter
from app.services.pathfinding import get_route

router = APIRouter()


@router.get("/api/route")
def route(start: str, destination: str):
    return get_route(start, destination)