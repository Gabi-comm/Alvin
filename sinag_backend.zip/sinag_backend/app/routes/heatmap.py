from fastapi import APIRouter
from app.firebase_config import get_data

router = APIRouter()


@router.get("/api/heatmap")
def heatmap():
    sensors = get_data("sensors")

    if not sensors:
        return []

    return [
        {
            "lat": sensor["latitude"],
            "lng": sensor["longitude"],
            "comfort_score": sensor["comfort_score"],
            "smoke_level": sensor["smoke_level"]
        }
        for sensor in sensors.values()
    ]