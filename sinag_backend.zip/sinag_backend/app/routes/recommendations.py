from fastapi import APIRouter
from app.services.recommendation import get_recommendations

router = APIRouter()


@router.get("/api/recommendations")
def recommendations():
    return get_recommendations()