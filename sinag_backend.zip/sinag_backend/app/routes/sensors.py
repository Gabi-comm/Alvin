from fastapi import APIRouter
from app.firebase_config import get_data, push_data
from app.schemas import SensorData
router = APIRouter()


@router.get("/api/sensors")
def get_sensors():
    return get_data("sensors")


@router.post("/api/sensors")
def post_sensor(sensor: SensorData):
    push_data("manual_sensors", sensor.model_dump())
    return {"message": "Sensor data stored"}