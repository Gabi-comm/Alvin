from fastapi import APIRouter
from app.weather import fetch_weather

router = APIRouter()


@router.get("/api/weather")
def weather():
    return fetch_weather()