import firebase_admin
from firebase_admin import credentials, db
from dotenv import load_dotenv
import os

load_dotenv()

if not firebase_admin._apps:
    cred = credentials.Certificate("firebase-service-account.json")
    firebase_admin.initialize_app(
        cred,
        {"databaseURL": os.getenv("FIREBASE_DB_URL")}
    )


def push_data(path, data):
    ref = db.reference(path)
    ref.push(data)


def set_data(path, data):
    ref = db.reference(path)
    ref.set(data)


def get_data(path):
    ref = db.reference(path)
    return ref.get()


def update_data(path, data):
    ref = db.reference(path)
    ref.update(data)