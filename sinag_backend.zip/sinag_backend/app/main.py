from fastapi import FastAPI
from contextlib import asynccontextmanager
from app.mock_data import start_sensor_thread
from app.routes import sensors, weather, recommendations, routing, emergency, heatmap


@asynccontextmanager
async def lifespan(app: FastAPI):
    start_sensor_thread()
    yield


app = FastAPI(
    title="ALVIN Backend",
    lifespan=lifespan
)

app.include_router(sensors.router)
app.include_router(weather.router)
app.include_router(recommendations.router)
app.include_router(routing.router)
app.include_router(emergency.router)
app.include_router(heatmap.router)


@app.get("/")
def root():
    return {"message": "ALVIN backend running"}